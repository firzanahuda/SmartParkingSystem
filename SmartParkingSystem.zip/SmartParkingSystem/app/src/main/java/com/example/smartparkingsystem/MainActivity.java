package com.example.smartparkingsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;


public class MainActivity extends AppCompatActivity {

    Button buttonSignup;
    Button buttonLogin;
    TextView textViewHome;
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonSignup = findViewById(R.id.btnSignUp);
        textViewHome = findViewById(R.id.textViewHome);
        buttonLogin = findViewById(R.id.btnLogin);

        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
            @Override
            public void onNavigationItemReselected(@NonNull MenuItem item) {

                Intent intent;
                switch (item.getItemId()){
                    case R.id.activity:
                        intent = new Intent(getApplicationContext(), Activity.class);
                        startActivity(intent);

                    case R.id.booking:
                        intent = new Intent(getApplicationContext(), Booking.class);
                        startActivity(intent);

                    case R.id.retrieve:
                        intent = new Intent(getApplicationContext(), Retrieve.class);
                        startActivity(intent);

                    case R.id.account:
                        intent = new Intent(getApplicationContext(), Account.class);
                        startActivity(intent);


                }

            }
        });

    }

    public void goToLoginActivity (View view){
        Intent intent = new Intent (this, Login.class);
        startActivity(intent);
    }

    public void goToSignupActivity (View view){
        Intent intent = new Intent (this, Registration.class);
        startActivity(intent);
    }
}
